# Checkpoint metadata audit

Status: **ERROR**

Metadata only. No full-model inference or tensor payload validation.

Tool: `0.7.0`
Model: `dealignai/GLM-5.3-CYBERSECURITY-FP8`
Revision: `5915c1b88f998a9c1e1a0c83688e285a08ae3ca5`
Stage: `validate_header`

Metadata structure verified: **False**
Real checkpoint runtime compatible: **False**
Full model loaded: **False**

## Error

MetadataError: Index total_size differs from complete header payload byte counts

## Coverage

```json
{
  "total_shards": 282,
  "selected_shards": 282,
  "checked_shards": 282,
  "total_index_tensors": 118629,
  "checked_tensors": 118629,
  "complete": false
}
```

## Metadata I/O

```json
{
  "body_bytes_read": 26349550,
  "read_calls": 741,
  "max_actual_read_bytes": 65536,
  "budget_bytes": 67108864,
  "mode": "online",
  "requests": 1133,
  "redirects": 566,
  "range_requests": 564,
  "response_hosts": [
    "huggingface.co",
    "us.aws.cdn.hf.co"
  ],
  "matching_repo_commit_headers": 567,
  "tensor_payload_bytes_requested": 0,
  "limits": {
    "total_body_bytes": 67108864,
    "max_requests": 4096,
    "timeout_seconds": 30,
    "total_seconds": 1800,
    "max_redirects": 5
  },
  "counter_scope": "Application metadata body reads; excludes HTTP/TLS buffers"
}
```

## Baseline comparison

```json
{
  "matched": true,
  "checked_fields": 15,
  "mismatches": [],
  "scope": "Only the fields and shard sizes in docs/model-metadata.json"
}
```

## Scope limits

- PASS is metadata-only; it never unblocks doctor or proves full-model inference.
- Scale values, NaNs, tensor payload checksums and numeric projection were not read/tested.
- Known-name shape checks are incomplete; unreviewed tensors are retained in the catalogue.
- Snapshot hashes detect local changes, not a forged snapshot with recomputed hashes.
- HTTP/body and header limits do not cap OS/TLS buffers or whole-system physical RAM.

Per-run evidence: `evidence/snapshot.json`; full observed catalogue: `tensor-catalogue.jsonl`.
These paths are relative to the per-run directory, not reports/.

## Traceback

```text
Traceback (most recent call last):
  File "D:\Project\llm\glm-local-32gb\glm_local\checkpoint_check.py", line 133, in execute_metadata
    raise MetadataError("Index total_size differs from complete header payload byte counts")
glm_local.checkpoint_http.MetadataError: Index total_size differs from complete header payload byte counts

```
