# Checkpoint metadata audit

Status: **PASS**

Metadata only. No full-model inference or tensor payload validation.

Tool: `0.7.1`
Model: `dealignai/GLM-5.3-CYBERSECURITY-FP8`
Revision: `5915c1b88f998a9c1e1a0c83688e285a08ae3ca5`
Stage: `complete`

Metadata structure verified: **True**
Real checkpoint runtime compatible: **False**
Full model loaded: **False**

## Coverage

```json
{
  "total_shards": 282,
  "selected_shards": 282,
  "checked_shards": 282,
  "total_index_tensors": 118629,
  "checked_tensors": 118629,
  "complete": true
}
```

## Metadata I/O

```json
{
  "body_bytes_read": 26349550,
  "read_calls": 741,
  "max_actual_read_bytes": 65536,
  "budget_bytes": 67108864,
  "mode": "online",
  "requests": 1133,
  "redirects": 566,
  "range_requests": 564,
  "response_hosts": [
    "huggingface.co",
    "us.aws.cdn.hf.co"
  ],
  "matching_repo_commit_headers": 567,
  "tensor_payload_bytes_requested": 0,
  "limits": {
    "total_body_bytes": 67108864,
    "max_requests": 4096,
    "timeout_seconds": 30,
    "total_seconds": 1800,
    "max_redirects": 5
  },
  "counter_scope": "Application metadata body reads; excludes HTTP/TLS buffers"
}
```

## Baseline comparison

```json
{
  "matched": true,
  "checked_fields": 15,
  "mismatches": [],
  "scope": "Only the fields and shard sizes in docs/model-metadata.json"
}
```

## Current runtime index policy

```json
{
  "metadata_audit_max_index_tensors": 262144,
  "current_reader_max_index_tensors": 8192,
  "current_reader_max_index_bytes": 1048576,
  "observed_index_bytes": 11359251,
  "observed_index_tensors": 118629,
  "fits_current_reader_index_policy": false,
  "reader_limits_changed": false
}
```

## Tensor review

```json
{
  "dtype_inventory": {
    "BF16": {
      "tensors": 465,
      "elements": 2103729152,
      "payload_bytes": 4207458304
    },
    "F8_E4M3": {
      "tensors": 59044,
      "elements": 751226191872,
      "payload_bytes": 751226191872
    },
    "F32": {
      "tensors": 59120,
      "elements": 45872560,
      "payload_bytes": 183490240
    }
  },
  "fp8_pairs": {
    "fp8_weights": 59044,
    "inspected_pairs": 59044,
    "cross_shard_pairs": 0,
    "current_adapter_metadata_matches": 59044
  },
  "fp8_adapter_metadata_verified": true,
  "findings": {
    "count": 0,
    "by_code": {},
    "examples": {},
    "max_examples_per_code": 8
  },
  "known_name_shape_checks": {
    "matched": 58794,
    "not_reviewed": 791
  },
  "unreviewed_tensor_examples": [
    "model.layers.78.eh_proj.weight",
    "model.layers.78.enorm.weight",
    "model.layers.78.hnorm.weight",
    "model.layers.78.input_layernorm.weight",
    "model.layers.78.mlp.experts.0.down_proj.weight",
    "model.layers.78.mlp.experts.0.gate_proj.weight",
    "model.layers.78.mlp.experts.0.up_proj.weight",
    "model.layers.78.mlp.experts.1.down_proj.weight",
    "model.layers.78.mlp.experts.1.gate_proj.weight",
    "model.layers.78.mlp.experts.1.up_proj.weight",
    "model.layers.78.mlp.experts.10.down_proj.weight",
    "model.layers.78.mlp.experts.10.gate_proj.weight",
    "model.layers.78.mlp.experts.10.up_proj.weight",
    "model.layers.78.mlp.experts.100.down_proj.weight",
    "model.layers.78.mlp.experts.100.gate_proj.weight",
    "model.layers.78.mlp.experts.100.up_proj.weight",
    "model.layers.78.mlp.experts.101.down_proj.weight",
    "model.layers.78.mlp.experts.101.gate_proj.weight",
    "model.layers.78.mlp.experts.101.up_proj.weight",
    "model.layers.78.mlp.experts.102.down_proj.weight",
    "model.layers.78.mlp.experts.102.gate_proj.weight",
    "model.layers.78.mlp.experts.102.up_proj.weight",
    "model.layers.78.mlp.experts.103.down_proj.weight",
    "model.layers.78.mlp.experts.103.gate_proj.weight",
    "model.layers.78.mlp.experts.103.up_proj.weight",
    "model.layers.78.mlp.experts.104.down_proj.weight",
    "model.layers.78.mlp.experts.104.gate_proj.weight",
    "model.layers.78.mlp.experts.104.up_proj.weight",
    "model.layers.78.mlp.experts.105.down_proj.weight",
    "model.layers.78.mlp.experts.105.gate_proj.weight",
    "model.layers.78.mlp.experts.105.up_proj.weight",
    "model.layers.78.mlp.experts.106.down_proj.weight"
  ],
  "architecture_mapping_verified": false,
  "largest_observed_matrices": [
    {
      "name": "lm_head.weight",
      "shape": [
        154880,
        6144
      ],
      "dtype": "BF16",
      "nbytes": 1903165440,
      "shard": "model-00001-of-00282.safetensors"
    },
    {
      "name": "model.embed_tokens.weight",
      "shape": [
        154880,
        6144
      ],
      "dtype": "BF16",
      "nbytes": 1903165440,
      "shard": "model-00001-of-00282.safetensors"
    },
    {
      "name": "model.layers.78.eh_proj.weight",
      "shape": [
        6144,
        12288
      ],
      "dtype": "BF16",
      "nbytes": 150994944,
      "shard": "model-00270-of-00282.safetensors"
    },
    {
      "name": "model.layers.0.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00001-of-00282.safetensors"
    },
    {
      "name": "model.layers.1.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00001-of-00282.safetensors"
    },
    {
      "name": "model.layers.10.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00005-of-00282.safetensors"
    },
    {
      "name": "model.layers.11.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00009-of-00282.safetensors"
    },
    {
      "name": "model.layers.12.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00013-of-00282.safetensors"
    },
    {
      "name": "model.layers.13.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00016-of-00282.safetensors"
    },
    {
      "name": "model.layers.14.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00020-of-00282.safetensors"
    },
    {
      "name": "model.layers.15.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00024-of-00282.safetensors"
    },
    {
      "name": "model.layers.16.self_attn.o_proj.weight",
      "shape": [
        6144,
        16384
      ],
      "dtype": "F8_E4M3",
      "nbytes": 100663296,
      "shard": "model-00027-of-00282.safetensors"
    }
  ],
  "scope": "Header dtype/shape/grid only; no scale values, graph completeness or dequantization verified"
}
```

## Scope limits

- PASS is metadata-only; it never unblocks doctor or proves full-model inference.
- Scale values, NaNs, tensor payload checksums and numeric projection were not read/tested.
- Known-name shape checks are incomplete; unreviewed tensors are retained in the catalogue.
- Snapshot hashes detect local changes, not a forged snapshot with recomputed hashes.
- HTTP/body and header limits do not cap OS/TLS buffers or whole-system physical RAM.

Per-run evidence: `evidence/snapshot.json`; full observed catalogue: `tensor-catalogue.jsonl`.
These paths are relative to the per-run directory, not reports/.
